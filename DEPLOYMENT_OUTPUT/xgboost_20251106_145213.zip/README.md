
# XGBoost - API Deployment Package
- Run locally: `pip install -r requirements.txt` then `uvicorn main:app --reload`
- Run with Docker: `docker build -t xgboost .` then `docker run -p 8000:8000 xgboost`
